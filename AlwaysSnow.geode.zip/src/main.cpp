#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

class $modify(AlwaysSnowMenuLayer, MenuLayer) {
	bool init() {
		if (!MenuLayer::init()) return false;

		// Don't stack a second emitter if the game already made one
		// (e.g. during the real Christmas event) or init runs twice.
		if (this->getChildByID("always-snow"_spr)) return true;

		int density = Mod::get()->getSettingValue<int64_t>("density");

		auto snow = CCParticleSnow::createWithTotalParticles(density);
		snow->setID("always-snow"_spr);
		// Cocos puts the emitter at the top-centre of the screen already;
		// just make sure it sits above the background but never eats touches.
		snow->setPositionType(kCCPositionTypeFree);
		this->addChild(snow, 100);

		return true;
	}
};
